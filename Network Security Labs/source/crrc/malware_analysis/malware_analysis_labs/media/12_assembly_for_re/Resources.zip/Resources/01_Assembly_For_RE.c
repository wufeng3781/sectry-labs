#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void loops(void);
void passCharArray(char charArray[]);


int main(void)
{
	int i = 0;
	int j = 7;
	char charArray1[10] = { 'c','h','a','r','a','r','r','a','y','\0' };
	char charArray2[10] = "chararray";
	
	printf("Printing the first char array: %s\n", charArray1);
	printf("Printing the second char array: %s\n", charArray2);

	if (i <= 10)
	{
		switch (j)
		{
		case 1:
			printf("case 1");
			break;
		case 2:
			printf("case 2");
			break;
		case 3:
			printf("case 3\n");
			break;
		}
	}

	loops();

	passCharArray(charArray2);

	return 0;
}

void loops()
{
	int i = 0;
	int j = 1;
	int integerArray[21];

	for (i = 0; i < 21; i++)
	{
		integerArray[i] = i;
	}

	while (j < 10)
	{
		j = j * 2;
	}

}

void passCharArray(char charArray[])
{
	int compare = 0;
	char passwordInput[20];
	printf("Enter Pass: ");
	scanf("%s", &passwordInput);
	compare = strcmp(charArray, passwordInput);

	if (compare == 0)
	{
		printf("Access Granted\n");
	}
	else
	{
		printf("Access Denied\n");
		passCharArray(charArray);
	}
}
