#include <stdio.h>

int bof_func() {

	char buff[16];

	gets(buff);

	printf(buff);
	printf("\n");
	fflush(stdout);

	if(strcmp(buff, "exit") == 0)
		return 0;
	else
		return 1;

}

int main() {

	while(bof_func());

}


