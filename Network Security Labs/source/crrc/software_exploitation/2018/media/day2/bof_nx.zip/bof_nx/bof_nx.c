#include <stdio.h>

void bof_func() {

	char buff[16];

	gets(buff);

}

int main(int argc, char *argv[]) {

	bof_func();

}