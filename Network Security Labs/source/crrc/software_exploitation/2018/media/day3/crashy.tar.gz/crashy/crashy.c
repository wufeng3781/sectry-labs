#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {

	FILE *fp;
	unsigned int sz, len, ptr;
	char *buffer;
	char type;
	char tmp_char;
	int	tmp_int;
	char *tmp_string;

	if(argc != 2) {
		fprintf(stderr, "Usage: %s <inputfile>\n", argv[0]);
		return 1;
	}

	fp = fopen(argv[1], "r");
	if(!fp) {
		fprintf(stderr, "Failed to open '%s'\n", argv[1]);
		return 1;
	}

	fseek(fp, 0, SEEK_END);
	sz = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	buffer = malloc(sz);
	if(!buffer) {
		fprintf(stderr, "Failed to allocate %d bytes of memory\n", sz);
		return 1;
	}

	fread(buffer, sizeof(char), sz, fp);

	ptr = 0;
	while(ptr < sz) {

		type = buffer[ptr++];
		switch(type) {

			case '\x01':	// integer
				tmp_int = *(int *)(buffer + ptr);
				ptr += sizeof(int);
				printf("i: 0x%08x\n", tmp_int);
				break;

			case '\x02':	// char
				tmp_char = buffer[ptr++];
				printf("c: 0x%02x\n", (unsigned char)tmp_char);
				break;

			case '\x03':	// string
				len = *(int *)(buffer + ptr);
				ptr += sizeof(int);
				tmp_string = malloc(len);
				if(!tmp_string) {
					fprintf(stderr, "Failed to allocate %d bytes of memory\n", len);
					return 1;
				}
				strcpy(tmp_string, (buffer + ptr));
				printf("s: %s\n", tmp_string);
				ptr += len;
				break;

			case '\x04':	// comment
				printf("#: %s\n", (buffer + ptr));
				while(*(buffer + ptr++) != '\x00');
				break;

			case '\xff':	// END
				return 0;

			default:
				fprintf(stderr, "Unknown data type '%c'\n", type);

		}

	}

}